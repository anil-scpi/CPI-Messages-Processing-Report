import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.time.TimeCategory

def Message processData(Message message) {
def properties = message.getProperties();
int s_Minutes = properties.get("Minutes").toInteger();
def currentDate = new Date()
LogEnd = (currentDate.format("yyyy-MM-dd'T'HH:mm:ss"))
use( TimeCategory ) {
logStart = currentDate -  s_Minutes.minutes
}
LogStart = (logStart.format("yyyy-MM-dd'T'HH:mm:ss"))
message.setProperty("logStart", LogStart);
message.setProperty("logEnd", LogEnd);
return message;
}