import com.sap.it.api.mapping.*;

/*
Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def void FAILEDCount(String[] status, String[] iflow, Output output, MappingContext context){
    
    def count = 0;
    
    for(int i=0;i<=iflow.length-1;i++){
        count = 0;
        for(j=0;j<=status.length-1;j++){
            if(status[j].contains(iflow[i]) && status[j].contains("FAILED"))
            {
                count++;
            }
        }
        output.addValue(count);
    }
}